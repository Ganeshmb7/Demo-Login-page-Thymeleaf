package com.spring.ton.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.spring.ton.model.User;
import com.spring.ton.web.dto.UserRegistrationDto;

public interface UserService extends UserDetailsService {
	
	User save(UserRegistrationDto registrationDto);
	
	

}
